from agents.research_agent import ResearchAgent
from agents.coding_agent import CodingAgent
from agents.testing_agent import TestingAgent

class TaskManager:
    def __init__(self):
        self.research_agent = ResearchAgent()
        self.coding_agent = CodingAgent()
        self.testing_agent = TestingAgent()

    def run_pipeline(self, topic: str):
        print("\n=== Starting Multi-Agent Workflow ===")

        # Step 1 → Research Agent
        research_output = self.research_agent.run(topic)

        # Step 2 → Coding Agent
        coding_output = self.coding_agent.run(research_output["result"])

        # Step 3 → Testing Agent
        testing_output = self.testing_agent.run(coding_output["generated_code"])

        return {
            "research": research_output,
            "coding": coding_output,
            "testing": testing_output
        }
