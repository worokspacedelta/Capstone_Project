class TestingAgent:
    def __init__(self):
        self.name = "Testing Agent"

    def run(self, code: str):
        print("[TestingAgent] Testing the provided code...")

        # Simulated test result
        result = {
            "status": "success",
            "details": "All tests passed. No runtime errors detected."
        }

        return {
            "agent": self.name,
            "task": "testing",
            "input": code,
            "result": result
        }
