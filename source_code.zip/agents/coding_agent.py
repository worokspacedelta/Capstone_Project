from utils.tools import code_quality_check

class CodingAgent:
    def __init__(self):
        self.name = "Coding Agent"

    def run(self, requirement: str):
        print(f"[CodingAgent] Generating code for: {requirement}")

        # Dummy code output (replace later with LLM)
        generated_code = f"""
def auto_generated_function():
    # TODO: Improve function
    print("This is auto-generated code for: {requirement}")
"""
        quality = code_quality_check(generated_code)

        return {
            "agent": self.name,
            "task": "coding",
            "input": requirement,
            "generated_code": generated_code,
            "quality_report": quality
        }
