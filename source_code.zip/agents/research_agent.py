from utils.tools import web_search

class ResearchAgent:
    def __init__(self):
        self.name = "Research Agent"

    def run(self, topic: str):
        print(f"[ResearchAgent] Researching topic: {topic}")
        data = web_search(topic)
        return {
            "agent": self.name,
            "task": "research",
            "input": topic,
            "result": data
        }
